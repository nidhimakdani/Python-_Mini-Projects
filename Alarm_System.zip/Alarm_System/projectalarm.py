# Author : Nidhi Makdani

from pygame import mixer
from datetime import datetime
from time import time


str_al = input("Note You Want During Your Alarm - ")
time_al = int(input("After How Many Seconds of Intervals You Want Alarm to be Ring? - "))
al_music = input("Enter a Name of Music File You Want to Ring during Alaram - ")
extention_music = input("Extention Of your File ex - .mp3 or .flac - ")

mixer.init()
mixer.music.load(al_music+extention_music)

msg = f"Your Alarm is set Successfully it's activated after every {time_al} Seconds!"
print(msg)

if __name__ == '__main__':
    maintime = time()
    Alarmsecs  = time_al

while True:
        if time() - maintime > Alarmsecs :
            print(str_al)
            print("For Stopping Alarm Type - Stop")
            mixer.music.play(-1)
            maintime = time()
            timer = input()
            if timer == "Stop":
                mixer.music.stop()
