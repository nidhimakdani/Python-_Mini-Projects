# Author : Nidhi Makdani

from pygame import mixer

print("WELCOME TO MUSIC PLAYER")

al_music = input("Song Name - ")
extention_music = input("Extention Of your Song ex - .mp3 or .flac - ")

mixer.init()
mixer.music.load(al_music+extention_music)

mixer.music.play(-1)

print("For Ending Music Type - Stop")
timer = input()
if timer == "Stop":
    mixer.music.stop()
